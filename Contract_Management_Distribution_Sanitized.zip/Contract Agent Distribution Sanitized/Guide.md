# 로컬 계약관리 Agent 사용 가이드

## 용도와 파일 구성

로컬 폴더에서 계약서를 읽어 대장을 만들고, 만료 예정 계약을 한 시트로 확인하는 Windows용 도구입니다. 원본 계약서는 읽기 전용으로 처리하며 Google Drive나 Codex 계정 없이 실행됩니다.

- `Contracts`에 원본 계약서를 보관합니다.
- `Contract_Master.xlsx`는 계약대장과 검토 필요 항목을 담습니다.
- `Reports/Contract_Expiration.xlsx`는 만료 예정 목록입니다.
- `recipients.txt`에는 보고서를 보내도 되는 이메일 주소를 관리합니다. 배포용 수신자 파일에는 주석으로 표시한 `[가림]`만 들어 있습니다.

### 배포 폴더 트리

```text
Contract Agent Distribution Sanitized/
├── Contracts/          계약서 입력 폴더 (초기에는 비어 있음)
├── Reports/            만료 보고서 저장 폴더 (초기에는 비어 있음)
├── contract_agent.py
├── run.ps1
├── requirements.txt
├── recipients.txt
├── Guide.md
└── .gitignore
```

## 설치 및 첫 실행

1. 배포 폴더를 쓰기 권한이 있는 로컬 위치에 복사합니다.
2. Windows용 Python 3.11 이상을 설치합니다. 처음 패키지를 설치할 때는 인터넷 연결이 필요합니다.
3. 복사한 폴더에서 PowerShell을 열고 아래 명령을 실행합니다. 가상환경에 필요한 패키지를 설치하고 빈 계약대장과 보고서를 생성합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 install
```

## 계약서 등록과 연장 이력

`Contracts`에 계약서를 넣고 아래 명령으로 갱신합니다. 계속 감시하려면 `scan` 대신 `watch`를 실행합니다. 감시는 파일 변경을 약 15초 간격으로 확인하며 Ctrl+C로 종료합니다. 갱신 전에 열려 있는 Excel 파일을 닫습니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 scan
```

- 텍스트가 있는 PDF와 DOCX를 읽습니다. 이미지형 PDF는 OCR 처리한 사본을 입력합니다. 구형 DOC는 LibreOffice를 설치하고 `CONTRACT_SOFFICE` 환경 변수에 `soffice.exe` 경로를 지정하거나 PATH에 추가합니다.
- 계약번호는 `CT-0001`부터 부여합니다. 파일이나 추출 본문이 동일한 사본은 한 번 등록합니다. 추출이 불확실한 항목은 **검토 필요** 시트에서 확인하고 대장에 직접 입력합니다.
- 연장 표시와 명시된 이전 번호가 있고 대장의 후보 하나와 일치하면 자동 연결합니다. 연결 대상이 불명확하면 B열 **이전 계약번호**에 바로 앞 계약번호를 입력합니다. 갱신하면 맨 오른쪽 **계약 이력**에 전체 연결이 표시됩니다. 예를 들어 `CT-0003 → CT-0002 → CT-0001`처럼 표시됩니다.
- 상태는 기록된 만료일이 지나면 **만료**, 만료일 당일까지는 **계약 중**입니다. 만료일이 없거나 날짜가 맞지 않으면 상태를 비워 두고 **검토 필요**에 표시합니다.

## 만료 보고서

**만료 예정** 시트는 한국 시간 기준으로 오늘부터 6개월 이내에 만료되는 계약을 한 줄씩 보여줍니다. 만료가 가까운 순으로 정렬하며, A열에서 **3개월 이내**는 연한 빨강, **3개월 초과~6개월 이내**는 연한 노랑으로 표시합니다. 당일 만료는 남은 일수 0일입니다. 자동갱신 조항이 있는 계약도 대장에 기록한 만료일을 기준으로 집계합니다.

## 수신자와 Gmail 설정

`recipients.txt`에 발송을 승인한 주소를 한 줄에 하나씩 입력하고 UTF-8로 저장합니다. 주소는 수신자별로 개별 발송되며, 빈 줄과 `#`으로 시작하는 줄은 건너뜁니다. 중복 주소는 한 번만 사용합니다.

발신 Gmail 계정에서 2단계 인증을 켜고 [Google 앱 비밀번호](https://support.google.com/mail/answer/185833?hl=ko)를 발급합니다. 아래 명령을 실행해 발신 주소와 앱 비밀번호를 입력하면 Windows에서 암호화해 해당 사용자용 설정 파일에 저장합니다. 테스트 전에 수신자 목록을 확인하세요. `test-mail`은 대장과 보고서를 갱신한 뒤 목록의 주소로 즉시 발송합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 setup-mail
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 test-mail
```

제목은 **계약서 만료 예정 알림**입니다. 첨부는 원본 경로를 뺀 `Contract_Expiration.xlsx` 한 개이며 계약대장과 원본 계약서는 첨부하지 않습니다.

## 주간 자동화와 문제 해결

Windows 시간대를 서울로 설정하고, 발신 설정에 사용한 Windows 계정에서 아래 명령을 실행합니다. Windows 작업 스케줄러의 **Contract Management Weekly**가 매주 월요일 오전 9시에 실행됩니다. 해당 시각에 PC가 켜져 있고 같은 Windows 사용자가 로그인해 있어야 합니다. 자동화를 멈추려면 작업 스케줄러에서 해당 작업을 사용 안 함으로 바꿉니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 schedule
```

메일이 보이지 않으면 `test-mail`의 실행 결과, 발신 계정의 보낸편지함·반송 메일, 수신 계정의 스팸함을 확인합니다. 배포할 때는 처음 받은 배포용 폴더를 공유합니다. 운영 중 생성된 계약서, Excel 파일, 발송 기록, 수신자 목록, Gmail 설정에는 이름, 연락처, 계좌 정보, 인증 정보가 들어갈 수 있습니다.

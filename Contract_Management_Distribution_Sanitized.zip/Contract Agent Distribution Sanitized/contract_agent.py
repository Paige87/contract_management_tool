import argparse
import calendar
import hashlib
import io
import msvcrt
import os
import re
import shutil
import smtplib
import ssl
import subprocess
import tempfile
import time
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path

from docx import Document
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
CONTRACTS = ROOT / "Contracts"
REPORTS = ROOT / "Reports"
RECIPIENTS = ROOT / "recipients.txt"
MASTER = ROOT / "Contract_Master.xlsx"
EXPIRATION = REPORTS / "Contract_Expiration.xlsx"
KST = timezone(timedelta(hours=9))
HEADERS = ["계약번호", "계약명", "상대방", "체결일", "만료일", "자동갱신 여부",
           "상태", "원본 파일 경로"]
INDEX = ["파일 SHA-256", "본문 SHA-256"]
HISTORY = ["이전 계약번호", "계약 이력"]
METADATA = ["원문 계약번호", "연장 참조", "연장 문서 표시"]
DATA_HEADERS = HEADERS + INDEX + HISTORY + METADATA
PREVIOUS_MASTER_ORDER = (0, 10, 11, *range(1, 10), *range(12, 15))
MASTER_ORDER = (0, 10, *range(1, 8), 11)
INTERNAL_ORDER = (0, 8, 9, 12, 13, 14)
INTERNAL_SHEET = "내부 관리"
WIDTHS = [15, 38, 31, 15, 15, 19, 23, 62, 24, 24, 19, 62, 24, 24, 24]
DATE = r"(\d{4})\s*(?:년\s*|[./-]\s*)(\d{1,2})\s*(?:월\s*|[./-]\s*)(\d{1,2})(?:\s*일)?"
FIELD = r"(?im)^[ \t]*(?:{labels})(?:[ \t]*[:：][ \t]*|[ \t]+)"


def extract_text(data, suffix):
    if suffix == ".pdf":
        return "\n".join(page.extract_text() or "" for page in PdfReader(io.BytesIO(data)).pages)
    if suffix == ".doc":
        converter = os.getenv("CONTRACT_SOFFICE") or shutil.which("soffice")
        if not converter:
            raise ValueError("구형 .doc 파일은 LibreOffice가 필요합니다. 설정은 README를 참고하세요.")
        with tempfile.TemporaryDirectory() as directory:
            scratch = Path(directory)
            source = scratch / "input.doc"
            source.write_bytes(data)
            subprocess.run(
                [converter, f"-env:UserInstallation={(scratch / 'profile').as_uri()}",
                 "--headless", "--convert-to", "docx", "--outdir", directory, str(source)],
                capture_output=True, check=True, timeout=90,
            )
            data = (scratch / "input.docx").read_bytes()
    document = Document(io.BytesIO(data))
    lines = [paragraph.text for paragraph in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            lines.append(": ".join(cell.text for cell in row.cells if cell.text.strip()))
    return "\n".join(lines)


def values_for(text, labels, pattern):
    return re.findall(FIELD.format(labels=labels) + pattern, text)


def unique(values):
    distinct = set(values)
    return distinct.pop() if len(distinct) == 1 else None


def parse_date(parts):
    try:
        return date(*map(int, parts))
    except ValueError:
        return None


def contract_fields(text):
    title = unique([value.strip() for value in values_for(
        text, r"계약\s*명(?:칭)?|계약\s*제목|Contract\s+Title", r"([^\r\n]+)"
    )])
    if not title:
        title = next((line.strip() for line in text.splitlines()[:8]
                      if re.fullmatch(r"[^:：]{1,90}계약서", line.strip())), None)
    party = unique([value.strip() for value in values_for(
        text, r"계약\s*상대방|상대방|수급인|공급자|Counterparty", r"([^\r\n]+)"
    )])
    if not party:
        parties = re.findall(
            r"(?m)^[ \t]*(?:(?:공급사|수급사|수급인|공급자)[ \t]*[（(]을[）)]"
            r"|을[ \t]+(?:공급사|수급사|수급인|공급자))"
            r"[ \t]*(?:[:：][ \t]*|\r?\n[ \t]*)([^/\r\n]+)(/)?", text
        )
        party = unique([name.strip() for name, detail in parties if detail]
                       or [name.strip() for name, _ in parties])
    signed = values_for(text, r"계약\s*체결일|체결일|서명일|Signed\s+Date|Execution\s+Date", DATE)
    if not signed:
        signed = re.findall(r"(?m)^[ \t]*(?:가상[ \t]+)?체결[ \t]+확인[ \t]*\|[ \t]*" + DATE, text)
    expiry = values_for(text, r"계약\s*만료일|만료일|종료일|Expiration\s+Date|Expiry\s+Date|End\s+Date", DATE)
    periods = re.findall(
        r"(?im)^[ \t]*(?:(?:최초[ \t]*)?계약\s*기간|유효\s*기간|연장\s*기간|Contract\s+Period)"
        r"(?:[ \t]*[:：][ \t]*|[ \t]+|[ \t]*\r?\n[ \t]*)"
        + DATE + r"\s*(?:부터\s*|[~～–—]\s*|to\s+|-\s+)" + DATE, text
    )
    expiry.extend(period[3:] for period in periods)
    expires_on = unique([parse_date(parts) for parts in expiry])
    signed_on = unique([parse_date(parts) for parts in signed])
    renewal = []
    for label in values_for(text, r"자동\s*갱신(?:\s*여부)?|Auto(?:matic)?[ -]Renewal", r"([^\r\n]+)"):
        label = label.strip().casefold()
        if label in {"예", "있음", "유", "yes", "y", "적용"}:
            renewal.append("예")
        elif label in {"아니오", "아니요", "없음", "무", "no", "n", "미적용"}:
            renewal.append("아니오")
    if not renewal:
        for line in text.splitlines():
            if re.search(r"자동(?:으로|\s*)\s*(?:갱신|연장)", line):
                if re.search(r"(?:갱신|연장)\s*(?:되지\s*않|하지\s*않|없)", line):
                    renewal.append("아니오")
                elif re.search(r"(?:갱신|연장)\s*(?:된다|됩니다|되는\s*것으로)", line):
                    renewal.append("예")
    return (title.strip() if title else None, party.strip() if party else None,
            signed_on, expires_on, unique(renewal) or "확인 필요")


def contract_references(text, title):
    number = r"([A-Z0-9]+(?:[-_./][A-Z0-9]+)*)(?=[ \t|,;)]|$)"
    source_id = unique([value.upper() for value in values_for(
        text, r"계약[ \t]*번호|Contract[ \t]*(?:No\.?|Number)", number
    )])
    references = set(value.upper() for value in values_for(
        text, r"(?:이전|직전|기존|원|연장[ \t]*대상)[ \t]*계약[ \t]*번호"
              r"|(?:Previous|Prior|Original)[ \t]+Contract[ \t]+(?:No\.?|Number)", number
    ))
    references.update(value.upper() for value in re.findall(
        r"(?im)^[ \t]*원[ \t]*계약[ \t]*번호[ \t]+및[ \t]+체결일[ \t]*\r?\n[ \t]*" + number,
        text,
    ))
    extension = bool(
        re.search(r"(?:연장|갱신)[ \t_-]*(?:계약|합의)|\b(?:extension|renewal)\s+agreement\b",
                  title or "", re.IGNORECASE)
        or values_for(text, r"연장[ \t]*대상[ \t]*계약[ \t]*번호", number)
        or re.search(r"(?:본[ \t]*(?:계약|합의)(?:서)?(?:로|는)|당사자(?:들)?는)"
                     r"[^\r\n.]{0,100}(?:계약[ \t]*기간|유효[ \t]*기간)[^\r\n.]{0,50}"
                     r"(?:연장|갱신)(?:한다|하기로|합니다)", text)
    )
    return [source_id or "-", "|".join(sorted(references)) or "-", "예" if extension else "아니오"]


def add_months(day, months):
    year, month = divmod(day.year * 12 + day.month - 1 + months, 12)
    return date(year, month + 1, min(day.day, calendar.monthrange(year, month + 1)[1]))


def cell_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        match = re.fullmatch(DATE, value.strip())
        return parse_date(match.groups()) if match else None
    return None


def populate(sheet, headers, rows, widths):
    sheet.append(headers)
    for row in rows:
        sheet.append(row)
        for cell in sheet[sheet.max_row]:
            if isinstance(cell.value, str):
                # Contract text is displayed literally, including leading '='.
                cell.data_type = "s"
            elif isinstance(cell.value, date):
                cell.number_format = "yyyy-mm-dd"
    for cell in sheet[1]:
        cell.font = Font(name="맑은 고딕", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="183A50")
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for i, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = width


def save(workbook, path):
    with tempfile.NamedTemporaryFile(dir=path.parent, suffix=".xlsx", delete=False) as temp:
        pending = Path(temp.name)
    try:
        workbook.save(pending)
        os.replace(pending, path)
    finally:
        pending.unlink(missing_ok=True)


def load_rows():
    if not MASTER.exists():
        return []
    with MASTER.open("rb") as source:
        workbook = load_workbook(source, read_only=True, data_only=True)
        try:
            header, *rows = workbook["계약대장"].values
            internal = {}
            if INTERNAL_SHEET in workbook:
                internal_header, *internal_rows = workbook[INTERNAL_SHEET].values
                if list(internal_header) != [DATA_HEADERS[i] for i in INTERNAL_ORDER]:
                    raise ValueError("내부 관리 시트의 열 구성이 바뀌었습니다.")
                internal = {row[0]: row for row in internal_rows}
        finally:
            workbook.close()
    header = list(header)
    if header not in (HEADERS + INDEX, HEADERS + INDEX + HISTORY,
                      [DATA_HEADERS[i] for i in PREVIOUS_MASTER_ORDER],
                      [DATA_HEADERS[i] for i in MASTER_ORDER]):
        raise ValueError("계약대장의 열 이름 또는 순서가 바뀌었습니다.")
    positions = {name: index for index, name in enumerate(header)}
    records = [[row[positions[name]] if name in positions else None for name in DATA_HEADERS]
               for row in rows]
    ids = [row[0] for row in records]
    if len(set(ids)) != len(ids) or any(not re.fullmatch(r"CT-\d{4,}", str(i)) for i in ids):
        raise ValueError("계약대장에 비어 있거나 중복된 계약번호가 있습니다.")
    if header == [DATA_HEADERS[i] for i in MASTER_ORDER]:
        if set(ids) != set(internal):
            raise ValueError("계약대장과 내부 관리 시트의 계약번호가 일치하지 않습니다.")
        for row in records:
            for index, value in zip(INTERNAL_ORDER[1:], internal[row[0]][1:]):
                row[index] = value
    return records


def scan(rows):
    by_bytes = {row[8]: row for row in rows if row[8]}
    by_text = {row[9]: row for row in rows if row[9]}
    by_path = {str(row[7]).casefold(): row for row in rows if row[7]}
    next_id = max((int(row[0][3:]) for row in rows), default=0) + 1
    issues = []
    for path in sorted(CONTRACTS.rglob("*"), key=lambda item: str(item).casefold()):
        if (path.suffix.lower() not in {".pdf", ".docx", ".doc"} or path.name.startswith("~$")
                or not path.is_file() or not path.resolve().is_relative_to(CONTRACTS.resolve())):
            continue
        relative = path.relative_to(ROOT).as_posix()
        try:
            data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            previous = by_path.get(relative.casefold())
            if previous and previous[8] == digest:
                if not previous[14] or not all(previous[1:5]) or previous[5] not in {"예", "아니오"}:
                    text = extract_text(data, path.suffix.lower())
                    extracted = contract_fields(text)
                    for index, value in enumerate(extracted, 1):
                        if value and (not previous[index] or (
                            index == 5 and previous[index] == "확인 필요"
                        )):
                            previous[index] = value
                    if not previous[14] or (previous[14] == "예" and previous[13] == "-"):
                        previous[12:15] = contract_references(text, previous[1])
                continue
            exact = by_bytes.get(digest)
            if exact is not None:
                if previous and exact is not previous:
                    raise ValueError("등록된 경로에 다른 계약의 사본이 있습니다.")
                if not previous and not (ROOT / exact[7]).is_file():
                    exact[7] = relative
                continue
            text = extract_text(data, path.suffix.lower())
            canonical = re.sub(r"\s+", "", text).casefold()
            if not canonical:
                raise ValueError("추출된 텍스트가 없습니다. 스캔본은 OCR 처리한 사본을 넣어 주세요.")
            text_hash = hashlib.sha256(canonical.encode()).hexdigest()
            duplicate = by_text.get(text_hash)
            if duplicate:
                if previous and duplicate is not previous:
                    raise ValueError("등록된 경로에 다른 계약의 사본이 있습니다.")
                if not previous and not (ROOT / duplicate[7]).is_file():
                    duplicate[7:10] = [relative, digest, text_hash]
                elif previous:
                    previous[8] = digest
                by_bytes[digest] = duplicate
                by_path[relative.casefold()] = duplicate
                continue
            if previous:
                raise ValueError("등록된 경로의 본문이 달라졌습니다. 새 계약이면 다른 파일명으로 추가하세요.")
            title, party, signed, expiry, renewal = contract_fields(text)
            record = [f"CT-{next_id:04d}", title or path.stem, party, signed, expiry,
                      renewal, None, relative, digest, text_hash, None, None,
                      *contract_references(text, title or path.stem)]
            rows.append(record)
            by_bytes[digest] = by_text[text_hash] = by_path[relative.casefold()] = record
            next_id += 1
        except Exception as error:
            issues.append([relative, f"{type(error).__name__}: {error}"])
    return issues


def update_history(rows, issues):
    lookup = {}
    for row in rows:
        for number in {row[0], row[12]} - {None, "-"}:
            lookup.setdefault(number, set()).add(row[0])
    for row in rows:
        if row[10] and str(row[10]).strip():
            continue
        if not row[13] or row[13] == "-":
            if row[14] == "예":
                issues.append([row[7], "연장·갱신 문서의 이전 계약번호를 확인해 입력하세요."])
            continue
        references = row[13].split("|")
        candidates = lookup.get(references[0], set())
        if row[14] == "예" and len(references) == 1 and len(candidates) == 1 and row[0] not in candidates:
            row[10] = next(iter(candidates))
        else:
            issues.append([row[7], "연장 참조를 확인해 이전 계약번호를 입력하세요: " + ", ".join(references)])

    predecessor = {row[0]: str(row[10]).strip().upper() if row[10] is not None else ""
                   for row in rows}
    for row in rows:
        contract_id = row[0]
        row[10] = predecessor[contract_id] or None
        chain = [contract_id]
        seen = {contract_id}
        current = predecessor[contract_id]
        problem = None
        while current:
            chain.append(current)
            if current in seen:
                problem = f"이전 계약 연결이 순환합니다 ({current})."
                break
            if current not in predecessor:
                problem = f"이전 계약번호를 대장에서 찾을 수 없습니다 ({current})."
                break
            seen.add(current)
            current = predecessor[current]
        if problem:
            issues.append([row[7], problem])
            row[11] = " → ".join(chain) + " (확인 필요)"
        else:
            row[11] = " → ".join(chain) if len(chain) > 1 else None


def refresh(today):
    rows = load_rows()
    issues = scan(rows)
    update_history(rows, issues)
    upcoming = []
    for row in rows:
        signed, expiry = map(cell_date, row[3:5])
        if not expiry or (signed and expiry < signed):
            row[6] = None
        elif expiry < today:
            row[6] = "만료"
            if row[5] == "예":
                issues.append([row[7], "기재된 만료일이 지났습니다. 자동갱신 결과를 확인하세요."])
        else:
            row[6] = "계약 중"
            if expiry <= add_months(today, 6):
                upcoming.append((expiry, row))
        missing = []
        for label, value in zip(("상대방", "체결일", "만료일"), (row[2], signed, expiry)):
            if not value:
                missing.append(label)
        if row[5] not in {"예", "아니오"}:
            missing.append("자동갱신 여부")
        if signed and expiry and expiry < signed:
            missing.append("체결일·만료일 순서")
        if missing:
            issues.append([row[7], "확인 필요: " + ", ".join(missing)])

    master = Workbook()
    master.active.title = "계약대장"
    populate(master.active, [DATA_HEADERS[i] for i in MASTER_ORDER],
             ([row[i] for i in MASTER_ORDER] for row in rows), [WIDTHS[i] for i in MASTER_ORDER])
    master.active["B1"].fill = PatternFill("solid", fgColor="24736B")
    populate(master.create_sheet("검토 필요"), ["원본 파일 경로", "확인 항목"], issues, [62, 100])
    hidden = master.create_sheet(INTERNAL_SHEET)
    populate(hidden, [DATA_HEADERS[i] for i in INTERNAL_ORDER],
             ([row[i] for i in INTERNAL_ORDER] for row in rows), [WIDTHS[i] for i in INTERNAL_ORDER])
    hidden.sheet_state = "veryHidden"
    save(master, MASTER)

    report = Workbook()
    sheet = report.active
    sheet.title = "만료 예정"
    three_month_cutoff = add_months(today, 3)
    upcoming.sort(key=lambda item: (item[0], item[1][0]))
    matches = [
        ["3개월 이내" if expiry <= three_month_cutoff else "3개월 초과~6개월 이내"]
        + row[:5] + [(expiry - today).days] + row[5:7]
        for expiry, row in upcoming
    ]
    populate(sheet, ["만료 구간"] + HEADERS[:5] + ["남은 일수"] + HEADERS[5:7],
             matches, [26] + WIDTHS[:5] + [15] + WIDTHS[5:7])
    period_colors = {"3개월 이내": ("FADBD8", "8B1E16"),
                     "3개월 초과~6개월 이내": ("FFF0B3", "654B00")}
    for row_number, match in enumerate(matches, 2):
        background, foreground = period_colors[match[0]]
        cell = sheet.cell(row_number, 1)
        cell.fill = PatternFill("solid", fgColor=background)
        cell.font = Font(name="맑은 고딕", bold=True, color=foreground)
    sheet["G1"].comment = Comment(f"기준일 {today} (한국 시간) · 집계 종료일 {add_months(today, 6)} 포함",
                                  "계약관리 Agent")
    save(report, EXPIRATION)
    print(f"{today} | 등록 {len(rows)}건 | 6개월 이내 {len(upcoming)}건 | 검토 {len(issues)}건", flush=True)


@contextmanager
def run_lock():
    with (ROOT / ".agent.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1):
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            raise RuntimeError("다른 계약관리 실행이 진행 중입니다. 잠시 뒤 다시 실행하세요.") from error
        try:
            yield
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def recipients():
    addresses = {}
    for index, line in enumerate(RECIPIENTS.read_text(encoding="utf-8-sig").splitlines(), 1):
        address = line.strip()
        if not address or address.startswith("#"):
            continue
        if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", address):
            raise ValueError(f"recipients.txt의 {index}번째 줄에 이메일 주소 하나를 입력하세요.")
        addresses.setdefault(address.casefold(), address)
    if not addresses:
        raise ValueError("recipients.txt에 발송을 승인한 수신자 주소를 입력하세요.")
    return list(addresses.values())


def send_report(now, weekly):
    if weekly and (now.weekday() != 0 or now.hour < 9):
        raise ValueError("주간 메일은 월요일 한국 시간 09:00 이후에 발송합니다.")
    marker = REPORTS / f".sent-{now.date().isoformat()}"
    sent = set(marker.read_text(encoding="ascii").splitlines()) if weekly and marker.exists() else set()
    remaining = {
        hashlib.sha256(address.casefold().encode("ascii")).hexdigest(): address
        for address in recipients()
    }
    for key in sent:
        remaining.pop(key, None)
    if not remaining:
        print("이번 주 보고서는 설정된 수신자에게 이미 발송했습니다.")
        return
    sender = os.getenv("CONTRACT_GMAIL_ADDRESS", "").strip()
    password = os.getenv("CONTRACT_GMAIL_APP_PASSWORD", "").replace(" ", "")
    if not sender or not password:
        raise ValueError("Gmail 발신 계정 설정이 필요합니다. README를 참고하세요.")
    attachment = EXPIRATION.read_bytes()
    failures = 0
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ssl.create_default_context(), timeout=30) as smtp:
        smtp.login(sender, password)
        for key, address in remaining.items():
            message = EmailMessage()
            message["From"] = sender
            message["To"] = address
            message["Subject"] = "계약서 만료 예정 알림"
            message.set_content("3개월 및 6개월 이내 만료 예정 계약서 목록을 첨부드립니다.")
            message.add_attachment(
                attachment, maintype="application",
                subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename=EXPIRATION.name,
            )
            try:
                if smtp.send_message(message):
                    failures += 1
                    continue
            except smtplib.SMTPRecipientsRefused:
                failures += 1
                continue
            if weekly:
                with marker.open("a", encoding="ascii") as progress:
                    progress.write(key + "\n")
    print(f"Gmail에 {len(remaining) - failures}건 발송 요청을 전달했습니다.")
    if failures:
        raise RuntimeError(f"Gmail이 수신자 {failures}건을 거부했습니다. 수신자 목록을 확인하세요.")


def main():
    parser = argparse.ArgumentParser(description="로컬 계약 대장 및 만료 보고서 갱신")
    parser.add_argument("mode", nargs="?", choices=("scan", "watch", "weekly", "test-mail"), default="scan")
    mode = parser.parse_args().mode
    CONTRACTS.mkdir(exist_ok=True)
    REPORTS.mkdir(exist_ok=True)
    last_snapshot = None
    while True:
        now = datetime.now(KST)
        snapshot = None
        try:
            if mode == "watch":
                snapshot = (now.date(), tuple(sorted(
                    (str(path), path.stat().st_mtime_ns)
                    for path in CONTRACTS.rglob("*") if path.is_file()
                )), MASTER.stat().st_mtime_ns if MASTER.exists() else None)
            if mode != "watch" or snapshot != last_snapshot:
                with run_lock():
                    refresh(now.date())
                    if mode in {"weekly", "test-mail"}:
                        send_report(now, weekly=mode == "weekly")
                if snapshot:
                    last_snapshot = (*snapshot[:2], MASTER.stat().st_mtime_ns)
        except (OSError, ValueError, RuntimeError, smtplib.SMTPException) as error:
            print(f"실행 오류: {error}", flush=True)
            if mode != "watch":
                return 1
        if mode != "watch":
            return 0
        time.sleep(15)


if __name__ == "__main__":
    raise SystemExit(main())

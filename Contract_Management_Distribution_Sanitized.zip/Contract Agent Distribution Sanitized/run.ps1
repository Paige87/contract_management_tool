param(
    [ValidateSet('install','scan','watch','setup-mail','test-mail','weekly','schedule')]
    [string]$Mode = 'scan'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$mailSettings = Join-Path $PSScriptRoot '.gmail.json'

if ($Mode -eq 'install') {
    if (-not (Test-Path -LiteralPath $python)) {
        $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($launcher) { & $launcher.Source -3 -m venv (Join-Path $PSScriptRoot '.venv') }
        else { & python -m venv (Join-Path $PSScriptRoot '.venv') }
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
    & $python -m pip install -r (Join-Path $PSScriptRoot 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    $Mode = 'scan'
}

if ($Mode -eq 'setup-mail') {
    $address = (Read-Host 'Gmail sender address').Trim()
    if ($address -notmatch '^[^\s@]+@[^\s@]+\.[^\s@]+$') { throw 'Enter a valid sender address.' }
    $secret = Read-Host 'Google app password' -AsSecureString
    if ($secret.Length -eq 0) { throw 'Enter a Google app password.' }
    @{
        Address = $address
        ProtectedPassword = ConvertFrom-SecureString -SecureString $secret
    } | ConvertTo-Json | Set-Content -LiteralPath $mailSettings -Encoding UTF8
    Write-Output 'Gmail settings saved for this Windows user.'
    exit 0
}

if (-not (Test-Path -LiteralPath $python)) { throw 'Run the install mode first.' }

if ($Mode -eq 'schedule') {
    if ((Get-TimeZone).Id -ne 'Korea Standard Time') { throw 'Set the Windows time zone to Seoul first.' }
    if (-not (Test-Path -LiteralPath $mailSettings)) { throw 'Run setup-mail first.' }
    $user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $action = New-ScheduledTaskAction -Execute (Join-Path $PSHOME 'powershell.exe') `
        -Argument ('-NoProfile -ExecutionPolicy Bypass -File "{0}" weekly' -f $PSCommandPath) `
        -WorkingDirectory $PSScriptRoot
    $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At ([datetime]::Today.AddHours(9))
    $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -RestartCount 2 -RestartInterval (New-TimeSpan -Minutes 10)
    Register-ScheduledTask -TaskName 'Contract Management Weekly' -Action $action -Trigger $trigger `
        -Principal $principal -Settings $settings -Force | Out-Null
    Write-Output 'Scheduled for Monday 09:00 KST under the current Windows user.'
    exit 0
}

if ($Mode -in @('weekly','test-mail')) {
    if (-not (Test-Path -LiteralPath $mailSettings)) { throw 'Run setup-mail first.' }
    $config = Get-Content -LiteralPath $mailSettings -Raw | ConvertFrom-Json
    $secure = ConvertTo-SecureString -String $config.ProtectedPassword
    $env:CONTRACT_GMAIL_ADDRESS = $config.Address
    $env:CONTRACT_GMAIL_APP_PASSWORD = [System.Net.NetworkCredential]::new('', $secure).Password
}
try {
    & $python (Join-Path $PSScriptRoot 'contract_agent.py') $Mode
    $result = $LASTEXITCODE
} finally {
    if ($Mode -in @('weekly','test-mail')) {
        Remove-Item Env:CONTRACT_GMAIL_APP_PASSWORD -ErrorAction SilentlyContinue
    }
}
exit $result
